import { BOOKS_PER_PAGE, authors, genres, books } from "./data.js";
import { genresFragment, authorsFragment } from "./Fragments.js";
import { themeSelect, themeMode, form, prefersDarkMode, initialTheme } from "./Theme.js";
import  "./Components.js";
let matches = books;
let page = 1;
const range = [0, 10];
if (!books || !Array.isArray(books)) {
  throw new Error('Source required');
}

if (!page || page.length < 2) {
  throw new Error('Range must be an array with two numbers');
}
const fragment = document.createDocumentFragment();


document.querySelector('[data-list-items]').appendChild(fragment);

document.querySelector('[data-search-genres]').appendChild(genresFragment);

document.querySelector('[data-search-authors]').appendChild(authorsFragment);

document.querySelector('[data-list-button]').textContent = `Show more (${Math.max(0, matches.length - page * BOOKS_PER_PAGE)})`;

document.querySelector('[data-list-button]').disabled === !(matches.length - page * BOOKS_PER_PAGE > 0);

document.querySelector('[data-list-button]').innerHTML = `
  <span>Show more</span>
  <span class="list__remaining">(${Math.max(0, matches.length - page * BOOKS_PER_PAGE)})</span>
`;




//search books according to their book preview Id
document.querySelector('[data-list-items]').addEventListener('click', (event) => {
  const pathArray = Array.from(event.path || event.composedPath());
  let active = null;

  for (const node of pathArray) {
    const previewId = node?.dataset?.preview;

    for (const singleBook of books) {
      if (singleBook.id == previewId) {
        active = singleBook;
        break;
      }
    }

    if (active) {
      break;
    }
  }

  if (!active) {
    return;
  }

  document.querySelector('[data-list-active]').showModal();
  document.querySelector('[data-list-blur]').src = active.image;
  document.querySelector('[data-list-title]').textContent = active.title;
  document.querySelector('[data-list-subtitle]').textContent = `${authors[active.author]} (${new Date(active.published).getFullYear()})`;
  document.querySelector('[data-list-description]').textContent = active.description;
});